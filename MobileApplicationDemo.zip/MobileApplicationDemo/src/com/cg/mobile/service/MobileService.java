package com.cg.mobile.service;

import java.util.ArrayList;

import com.cg.mobile.dao.IMobileDao;
import com.cg.mobile.dao.MobileDao;
import com.cg.mobile.dto.MobileDetails;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.mobileException;

public class MobileService implements IMobileService{
	IMobileDao dao;
	public MobileService() {
		dao=new MobileDao();
	}

	@Override
	public int addPurchaseDetail(PurchaseDetails purchaseDetails) throws mobileException {
		// TODO Auto-generated method stub
		return dao.addPurchaseDetail(purchaseDetails);
	}

	@Override
	public int updateMobileQty(int mobileid, int quantity) throws mobileException {
		// TODO Auto-generated method stub
		return dao.updateMobileQty(mobileid, quantity);
	}

	@Override
	public ArrayList<MobileDetails> getMobileDetail() throws mobileException {
		// TODO Auto-generated method stub
		return dao.getMobileDetail();
	}

	@Override
	public ArrayList<MobileDetails> getAllMobileDetails() throws mobileException {
		// TODO Auto-generated method stub
		return dao.getAllMobileDetails();
	}
}
