package com.cg.mobile.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobile.dto.MobileDetails;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.mobileException;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileService;



public class Main {
	public void acceptPuchaseDetails(PurchaseDetails purchaseDetails)throws mobileException{
		IMobileService service=new MobileService();
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter Customer Name : ");
		String cname=sc.next();
		System.out.println("Enter mail Id : ");
		String mailid=sc.next();
		System.out.println("Enter phone number : ");
		String phoneno=sc.next();
		System.out.println("Enter Purchase Date :(dd-MM-yyyy) ");
		String str=sc.next();
		
		DateTimeFormatter fmt= DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date=LocalDate.parse(str, fmt);
		/*System.out.println("Select Department : ");
		ArrayList<Department> list=service.getDepartments();
		for(Department dept:list){
			System.out.println(dept.getDeptNo()+" "+dept.getDeptName());
		}
		int no=sc.nextInt();*/
		System.out.println("Select Mobile id.....");
		ArrayList<MobileDetails> list=service.getMobileDetail();
		for(MobileDetails mobDt:list) {
			System.out.println(mobDt.getMobileid()+" "+mobDt.getName());
		}
		int no=sc.nextInt();
		
		/*purchaseDetails.getPurchaseid();
		purchaseDetails.getCname();
		purchaseDetails.getMailid();
		purchaseDetails.getPhoneno();
		purchaseDetails.getPurchaseDate();*/
		
		purchaseDetails.setCname(cname);
		purchaseDetails.setMailid(mailid);
		purchaseDetails.setPhoneno(phoneno);
		purchaseDetails.setPurchaseDate(date);
		purchaseDetails.setMobileid(no);
		
		
	}
	/*public void updateMobileQty() throws mobileException{
		IMobileService service=new MobileService();
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter Mobile id whose quantity is to be changed...");
		int mobileid=sc.nextInt();
		System.out.println("Enter quantity");
		int quantity=sc.nextInt();
		service.updateMobileQty(quantity, mobileid);
		System.out.println("udated quantity....");
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main obj=new Main();
		IMobileService service=new MobileService();
		PurchaseDetails purchaseDetails=new PurchaseDetails();
		Scanner sc =new Scanner(System.in);
		while(true) {
		try {
			System.out.println("-------Menu----------");
			System.out.println("1. Add Purchase Details");
			System.out.println("2. update Mobile Quantity");
			System.out.println("3. View details of Mobile");
			System.out.println("4. Delete mobile details ");
			int ch= sc.nextInt();
			switch(ch) {
			case 1:
				obj.acceptPuchaseDetails(purchaseDetails);
				System.out.println("data added to table......");
				int purchaseid=service.addPurchaseDetail(purchaseDetails);
				System.out.println("Record inserted......"+purchaseid);
				break;
			case 2:	
				System.out.println("Enter Mobile id whose quantity is to be changed...");
				int mobileid=sc.nextInt();
				System.out.println("Enter quantity");
				int quantity=sc.nextInt();
				service.updateMobileQty(quantity, mobileid);
				System.out.println("udated quantity....");
				break;
			case 3:
				System.out.println("....Mobile Details are.....");
				ArrayList<MobileDetails> list=service.getAllMobileDetails();
				for(MobileDetails mobDetail:list) {
					//System.out.println("MobileId  Mobile Name  Price Quantity");
					System.out.println(mobDetail.getMobileid()+" "+mobDetail.getName()+" "+mobDetail.getPrice()+" "+mobDetail.getQuantity());
				}
				//int no=sc.nextInt();
				break;
			}
			//obj.updateMobileQty();
			
			
		}catch (mobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}

}
/*Main obj= new Main();
IStudentService service= new StudentServiceImpl();
Student student= new Student();
Scanner sc= new Scanner(System.in);
while(true){
try {
	System.out.println("-------Menu----------");
	System.out.println("1. add student");
	System.out.println("2. update Student address");
	System.out.println("3. Delete student");
	System.out.println("4. Display Student List ");
	int ch= sc.nextInt();
	switch(ch){
	case 1 :
		obj.acceptStudentDetails(student);
		student= service.validateStudentDetails(student);
		int rollno= service.addStudent(student);
	System.out.println("Record inserted..."+ rollno );
		break;
	case 2 : 
		System.out.println("Enter Address ");
		String address = sc.next();
		System.out.println("Enter rollno ");
		int rn= sc.nextInt();
		int res= service.updateStudentAddress(address, rn);
			if(res==1){
			lg.info("address Updated for : "+ rn);
				System.out.println("address updated ");
			}
			else{
				lg.error("Rollno :"+ rn+" not found ");
				System.out.println("No record found for : "+ rn);
			}
			break;
	case 4: 
		System.out.println("Enter dept No ");
		int dno= sc.nextInt();
		ArrayList<Student> list= service.getStudentList(dno);
		if(list.size()==0){
			System.out.println("No record found");
			lg.error("List is empty");
		}
		else {
			for(Student s: list){
				System.out.println(s);
			}
		}
		break;
	}
} catch (AdmissionException e) {
	lg.error(e.getMessage());
	System.out.println(e.getMessage());
}
}//end of while
}//end of main 
}// end of class

*/
