package com.cg.controller;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.dto.Hotel;
import com.cg.service.BookingServiceImpl;
import com.cg.service.IBookingService;
@Controller
public class BookingController {
	@Autowired
	IBookingService hotelSer=new BookingServiceImpl();
	public IBookingService getHotelSer() {
		return hotelSer;
	}
	public void setHotelSer(IBookingService hotelSer) {
		this.hotelSer = hotelSer;
	}
		@RequestMapping(value="ViewHotels")
	public String viewHotels(Model model,ArrayList<Hotel> hotels) {
		hotels=(ArrayList<Hotel>) hotelSer.viewHotels();
		model.addAttribute("hotels", hotels);
		return "HotelDetails";
	}
	@RequestMapping(value="boss.obj",method=RequestMethod.GET)
	public String viewBookedHotels(@RequestParam(value="uid")String name,Model model,Hotel hotel) {
		int hotelId;
		if(name.equals("Hyatt"))
			hotelId=1;
		else if(name.equals("Haveli"))
			hotelId=2;
		else
			hotelId=3;
		hotelSer.bookHotel(hotelId);
		model.addAttribute("message", name);
		return "HotelBookingSuccess";
	}
	
	
}
