package com.cg.service;

import java.util.List;

import com.cg.dto.Hotel;

public interface IBookingService {
	public List<Hotel> viewHotels();
	public Hotel bookHotel(int hotelId);
}
