package com.cg.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.BookingDAOImpl;
import com.cg.dao.IBookingDAO;
import com.cg.dto.Hotel;
@Service(value="hotelSer")

public class BookingServiceImpl implements IBookingService {
	@Autowired
	IBookingDAO bookingDao=new BookingDAOImpl();

	public IBookingDAO getBookingDao() {
		return bookingDao;
	}
	public void setBookingDao(IBookingDAO bookingDao) {
		this.bookingDao = bookingDao;
	}
	
	@Override
	public List<Hotel> viewHotels() {
		return bookingDao.viewHotels();
	}

	@Override
	public Hotel bookHotel(int hotelId) {
		return bookingDao.bookHotel(hotelId);
	}
	
}
