package com.cg.dao;
import java.util.List;

import com.cg.dto.*;

public interface IBookingDAO {
	public List<Hotel> viewHotels();
	public Hotel bookHotel(int hotelId);
	}
