package com.cg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.Hotel;

@Repository(value="hotelDao")
@Transactional
public class BookingDAOImpl implements IBookingDAO{
	@PersistenceContext
	EntityManager entityManager =null;
	
	@Override
	public List<Hotel> viewHotels() {
		return entityManager.createQuery("from Hotel h",Hotel.class).getResultList();
	}

	@Override
	public Hotel bookHotel(int hotelId) {
		Hotel hotel=entityManager.find(Hotel.class, hotelId);
		hotel.setAvaialableRooms(hotel.getAvaialableRooms()-1);
		return hotel;
	}

	

}
