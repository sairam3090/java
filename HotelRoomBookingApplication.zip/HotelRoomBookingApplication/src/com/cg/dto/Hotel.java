package com.cg.dto;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Hotel {
	@Id
	private int id;
	private String name;
	private String rating;
	private int rateNumber;
	private int avaialableRooms;
	public Hotel() {}
	public Hotel(int id, String name, String rating, int rateNumber, int avaialableRooms) {
		super();
		this.id = id;
		this.name = name;
		this.rating = rating;
		this.rateNumber = rateNumber;
		this.avaialableRooms = avaialableRooms;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public int getRateNumber() {
		return rateNumber;
	}
	public void setRateNumber(int rateNumber) {
		this.rateNumber = rateNumber;
	}
	public int getAvaialableRooms() {
		return avaialableRooms;
	}
	public void setAvaialableRooms(int avaialableRooms) {
		this.avaialableRooms = avaialableRooms;
	}
	@Override
	public String toString() {
		return "Hotel [id=" + id + ", name=" + name + ", rating=" + rating + ", rateNumber=" + rateNumber
				+ ", avaialableRooms=" + avaialableRooms + "]";
	}
	
}
