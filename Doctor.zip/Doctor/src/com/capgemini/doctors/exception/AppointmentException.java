package com.capgemini.doctors.exception;

public class AppointmentException extends Exception {

	public AppointmentException(String s){
		super(s);
	}
}
