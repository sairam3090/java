package com.capgemini.doctors.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
  public static Connection getConnection(){
	  Connection con=null;
	  String user;
	  String password;
	  String url;
	  String driver;
	  try{
			InputStream file=new FileInputStream("./resources/dbconfig.properties");
			Properties prop= new Properties();
			prop.load(file);
	        user=prop.getProperty("username");
		    password=prop.getProperty("password");
		    url=prop.getProperty("url");
		    driver=prop.getProperty("driver");
	     
		  Class.forName(driver);
		  con=DriverManager.getConnection(url, user, password);
		  System.out.println("Database Connected..");
		  file.close();
	  }
	  catch(ClassNotFoundException e){
            System.out.println("Driver Class not loaded ..");		  
	  }
	  catch(SQLException e){
		  System.out.println(e);
	  } 
	  catch(FileNotFoundException e){
			System.out.println("File not found");
		}
	  catch(IOException e){
		  System.out.println(e.getMessage());
		}
	  return con;
  }
  public static void main(String[] args) {
	getConnection();
}
}