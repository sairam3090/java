package com.capgemini.doctors.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.AppointmentException;


public class DoctorAppointmentService implements IDoctorAppointmentService {

	IDoctorAppointmentDao rdao = new DoctorAppointmentDao();
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)
			throws AppointmentException {
		
		return rdao.addDoctorAppointmentDetails(doctorAppointment);
	}

	@Override
	public List<DoctorAppointment> getDoctorAppointmentDetails(int appointmentId)
			throws AppointmentException {

		return rdao.getAppointmentDetails(appointmentId);
	}

	@Override
	public void validateDoctor(DoctorAppointment docApp) {
		
		if(docApp.getProblemName()=="Heart"){
			docApp.setDoctorName("Dr. Brijesh Kumar");
			docApp.setAppointmentStatus("APPROVED");
		}
		else if(docApp.getProblemName()=="Gynecology"){
			docApp.setDoctorName("Dr. Sharda Singh");
			docApp.setAppointmentStatus("APPROVED");
		}
		else if(docApp.getProblemName()=="Diabetes"){
			docApp.setDoctorName("Dr. Heena Khan");
			docApp.setAppointmentStatus("APPROVED");
		}
		else if(docApp.getProblemName()=="ENT"){
			docApp.setDoctorName("Dr. Paras mal");
			docApp.setAppointmentStatus("APPROVED");
		}
		else if(docApp.getProblemName()=="Bone"){
			docApp.setDoctorName("Dr. Renuka Kher");
			docApp.setAppointmentStatus("APPROVED");
		}
		else if(docApp.getProblemName()=="Dermatology"){
			docApp.setDoctorName("Dr. Knika Kapoor");
			docApp.setAppointmentStatus("APPROVED");
		}
		else{
			docApp.setDoctorName(null);
			docApp.setAppointmentStatus("DISAPPROVED");
		}

		
	}

	@Override
	public boolean ValidateInput(DoctorAppointment docApp) throws AppointmentException {
		
		if(!docApp.getPatienceName().matches("[A-Z]{1}[a-zA-Z]{2,20}")){
			throw new AppointmentException("Student Name Should start with Captial and contains Characters Only");
		}
		if(!docApp.getProblemName().matches("[A-Z]{1}[a-zA-Z]{2,20}")){
			throw new AppointmentException("Student Name Should start with Captial and contains Characters Only");
		}
		if(!docApp.getEmail().matches(".*@.*.com")){
			throw new AppointmentException("Enter Valid Email with @ and .com");
		}
		if(!docApp.getPhoneNumber().matches("[7|8|9]{1}[0-9]{9}")){
			throw new AppointmentException("Phone Number Should be of 10 Digits Starting with 7/8/9");
		}
		if(docApp.getDateOfAppointment().before(Date.valueOf(LocalDate.now()))){
			throw new AppointmentException("Registration date should be before Today's Date");
		}
		return true;
	}

}
